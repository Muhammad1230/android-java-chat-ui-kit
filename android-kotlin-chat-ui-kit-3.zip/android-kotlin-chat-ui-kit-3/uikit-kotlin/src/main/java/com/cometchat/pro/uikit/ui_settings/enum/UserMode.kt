package com.cometchat.pro.uikit.ui_settings.enum

enum class UserMode(private val label: String) {
    ALL_USER("all_users"), FRIENDS("friends");
}